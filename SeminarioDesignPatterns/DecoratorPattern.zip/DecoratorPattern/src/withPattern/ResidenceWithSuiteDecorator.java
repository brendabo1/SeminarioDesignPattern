package withPattern;

import java.math.BigDecimal;

public class ResidenceWithSuiteDecorator extends ResidenceDecorator {
	
	private BigDecimal cost; //suite cost
	private int roomCount; //quantity of rooms added with the suite
	
	public ResidenceWithSuiteDecorator(Residence decoratedResidence) {
		super(decoratedResidence);
		this.cost = BigDecimal.valueOf(18000);
		this.roomCount = 2;
	}
	
	@Override
	public BigDecimal getCost() {
		//adds 18K to the wrapped residence object's cost
		return this.decoratedResidence.getCost().add(this.cost);
	}
	
	@Override
	public int getRoomCount() {
		// adds 2 to the wrapped residence object's room count
		return this.decoratedResidence.getRoomCount() + this.roomCount;
	}
}
