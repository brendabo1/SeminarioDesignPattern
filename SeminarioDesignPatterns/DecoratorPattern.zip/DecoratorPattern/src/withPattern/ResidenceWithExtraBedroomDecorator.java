package withPattern;

import java.math.BigDecimal;

public class ResidenceWithExtraBedroomDecorator extends ResidenceDecorator {
	
	private BigDecimal cost; //extra bedroom cost
	private int roomCount; //quantity of rooms added with the extra bedroom  
	
	
	//Constructor
	public ResidenceWithExtraBedroomDecorator(Residence decoratedResidence) {
		super(decoratedResidence);
		this.cost = BigDecimal.valueOf(10000);
		this.roomCount = 1;
	}

	@Override
	public BigDecimal getCost() {
		// adds 10K to the wrapped residence object's cost
		return this.decoratedResidence.getCost().add(this.cost);
	}

	@Override
	public int getRoomCount() {
		// adds 1 to the wrapped residence object's room count
		return this.decoratedResidence.getRoomCount() + this.roomCount;
	}
}
