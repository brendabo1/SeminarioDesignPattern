package withPattern;

import java.math.BigDecimal;

public abstract class Residence {
	
	//return the total cost of the residence
	public abstract BigDecimal getCost();
	
	//returns the total room count of the residence
	public abstract int getRoomCount();
}
