package withPattern;

import java.math.BigDecimal;

public class ResidenceWithPoolDecorator extends ResidenceDecorator {

	private BigDecimal cost; // pool cost

	// doesn't add any room to the total of rooms
	// therefore the attribute roomCount isn't necessary;


	// Constructor
	public ResidenceWithPoolDecorator(Residence decoratedResidence) {
		super(decoratedResidence);
		this.cost = BigDecimal.valueOf(15000);
	}

	@Override
	public BigDecimal getCost() {
		// adds 15K to the wrapped residence object's cost
		return this.decoratedResidence.getCost().add(this.cost);
	}

	@Override
	public int getRoomCount() {
		// returns the wrapped residence object's room count
		return this.decoratedResidence.getRoomCount();
	}

}
