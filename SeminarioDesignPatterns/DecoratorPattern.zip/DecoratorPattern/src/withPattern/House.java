package withPattern;

import java.math.BigDecimal;

public class House extends Residence {
	
	private BigDecimal cost; //initial cost of a house
	private int roomCount; //initial room count of the house
	
	//Constructor
	public House (BigDecimal initCost, int initRoomCount) {
		this.cost = initCost;
		this.roomCount = initRoomCount;
	}
	
	@Override
	public BigDecimal getCost() {
		return this.cost;

	}

	@Override
	public int getRoomCount() {
		return this.roomCount;

	}

}
