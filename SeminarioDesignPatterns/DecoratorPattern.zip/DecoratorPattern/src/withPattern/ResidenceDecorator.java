package withPattern;

public abstract class ResidenceDecorator extends Residence {
	
	//instace of the residence object
	// wrapped by this object
	protected Residence decoratedResidence;
	
	
	//Constructor
	public ResidenceDecorator(Residence decoratedResidence) {
		this.decoratedResidence = decoratedResidence;
	}
}
