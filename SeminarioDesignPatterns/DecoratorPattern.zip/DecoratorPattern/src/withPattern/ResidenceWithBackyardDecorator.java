package withPattern;

import java.math.BigDecimal;

public class ResidenceWithBackyardDecorator extends ResidenceDecorator {
	
	// cost 
	private BigDecimal cost; //backyard cost
	
	//doesn't add any room to the total of rooms
	//therefore the attribute roomCount isn't necessary;
	
	
	public ResidenceWithBackyardDecorator(Residence decoratedResidence) {
		super(decoratedResidence);
		this.cost  = BigDecimal.valueOf(3000);
	}
	
	@Override
	public BigDecimal getCost() {
		//adds 3K to the wrapped residence object's cost
		return this.decoratedResidence.getCost().add(this.cost);
	}
	
	@Override
	public int getRoomCount() {
		// returns the wrapped residence object's room count
		return this.decoratedResidence.getRoomCount();
	}

}
