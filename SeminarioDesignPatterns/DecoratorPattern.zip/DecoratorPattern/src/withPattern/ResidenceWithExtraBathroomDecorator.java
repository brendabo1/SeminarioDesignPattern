package withPattern;

import java.math.BigDecimal;

public class ResidenceWithExtraBathroomDecorator extends ResidenceDecorator {
	
	private BigDecimal cost; //extra bathroom cost
	private int roomCount; //quantity of rooms added with the extra bathroom
	
	public ResidenceWithExtraBathroomDecorator(Residence decoratedResidence) {
		super(decoratedResidence);
		this.cost = BigDecimal.valueOf(7000);
		this.roomCount = 1;

	}

	@Override
	public BigDecimal getCost() {
		// adds 7K to the wrapped residence object's cost
		return this.decoratedResidence.getCost().add(this.cost);
	}

	@Override
	public int getRoomCount() {
		// adds 1 to the wrapped residence object's room count
		return this.decoratedResidence.getRoomCount() + this.roomCount;
	}
}
