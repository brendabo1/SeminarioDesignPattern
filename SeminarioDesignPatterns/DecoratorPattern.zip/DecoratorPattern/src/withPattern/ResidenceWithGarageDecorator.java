package withPattern;

import java.math.BigDecimal;

public class ResidenceWithGarageDecorator extends ResidenceDecorator {
	
	private BigDecimal cost; //garage cost
	private int roomCount; //quantity of rooms added with the garage
	
	public ResidenceWithGarageDecorator(Residence decoratedResidence) {
		super(decoratedResidence);
		this.cost = BigDecimal.valueOf(4000);
		this.roomCount = 1;
	}
	
	@Override
	public BigDecimal getCost() {
		// adds 4K to the wrapped residence object's cost
		return this.decoratedResidence.getCost().add(this.cost);
	}
	
	@Override
	public int getRoomCount() {
		// adds 1 to the wrapped residence object's room count
		return this.decoratedResidence.getRoomCount() + this.roomCount;
	}
	
}
