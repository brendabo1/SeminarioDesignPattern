package withoutPattern;

import java.math.BigDecimal;

public abstract class Residence {
	protected BigDecimal cost;
	protected int roomCount;
	protected boolean hasPool;
	protected boolean hasGarage;
	protected boolean hasBackyard;
	protected boolean hasSuite;
	protected boolean hasExtraBedroom;
	protected boolean hasExtraBathroom;

	public Residence(BigDecimal initCost, int initRoomCount) {
		this.cost = initCost;
		this.roomCount = initRoomCount;
	}

	public abstract BigDecimal getCost();

	public abstract int getRoomCount();

	public abstract void setHasPool(boolean option);

	public abstract void setHasBackyard(boolean option);

	public abstract void setHasGarage(boolean option);

	public abstract void setHasExtraBedroom(boolean option);

	public abstract void setHasExtraBathroom(boolean option);

	public abstract void setHasSuite(boolean option);
}
