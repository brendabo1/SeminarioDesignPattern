package withoutPattern;

import java.math.BigDecimal;

public class House extends Residence {

	public House(BigDecimal initCost, int initRoomCount, boolean hasPool, boolean hasGarage, 
			boolean hasBackyard,boolean hasSuite, boolean hasExtraBedroom, 
			boolean hasExtraBathroom) {
		
		super(initCost, initRoomCount);
		
		// Additions
		setHasPool(hasPool);
		setHasGarage(hasGarage);
		setHasBackyard(hasBackyard);
		setHasSuite(hasSuite);
		setHasExtraBedroom(hasExtraBedroom);
		setHasExtraBathroom(hasExtraBathroom);
	}

	@Override
	public BigDecimal getCost() {
		return this.cost;
	}

	@Override
	public int getRoomCount() {
		return this.roomCount;
	}

	@Override
	public void setHasPool(boolean option) {
		// cost of a pool is 15K
		if (option) {
			this.cost = this.cost.add(BigDecimal.valueOf(15000));
			
		}
	}

	@Override
	public void setHasBackyard(boolean option) {
		// cost of a backyard is 3K
		if (option) {
			this.cost = this.cost.add(BigDecimal.valueOf(3000));
		}
	}

	@Override
	public void setHasGarage(boolean option) {
		// cost of a garage is 4K
		if (option) {
			this.cost = this.cost.add(BigDecimal.valueOf(4000));
		}
	}

	@Override
	public void setHasExtraBedroom(boolean option) {
		// cost of a extra bedroom is 10K
		// adds 1 room to the count
		if (option) {
			this.cost = this.cost.add(BigDecimal.valueOf(10000));
			this.roomCount++;
		}
	}

	@Override
	public void setHasExtraBathroom(boolean option) {
		// cost of a bathroom is 7K
		// adds 1 room to the room count
		if (option) {
			this.cost = this.cost.add(BigDecimal.valueOf(7000));
			this.roomCount++;
		}
	}

	@Override
	public void setHasSuite(boolean option) {
		// cost of a suite is 18K
		// adds 2 rooms to the room count
		if (option) {
			this.cost = this.cost.add(BigDecimal.valueOf(18000));
			this.roomCount += 2;
		}
	}

}
