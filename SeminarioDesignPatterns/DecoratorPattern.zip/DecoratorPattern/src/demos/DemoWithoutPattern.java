package demos;

import java.math.BigDecimal;

import withoutPattern.House;
import withoutPattern.Residence;

public class DemoWithoutPattern {

	public static void main(String[] args) {
		
		Residence house = new House(BigDecimal.valueOf(50000), 5, true, false, false, true, false, false);
		
		//House with one suite and a pool
		System.out.println("Casa com 1 su�te e piscina");
		System.out.println("Room count: "+ house.getRoomCount());
		System.out.println("Cost: "+house.getCost());
	}

}
