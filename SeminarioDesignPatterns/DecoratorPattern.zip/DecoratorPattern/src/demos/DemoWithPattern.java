package demos;

import java.math.BigDecimal;

import withPattern.House;
import withPattern.Residence;
import withPattern.ResidenceWithPoolDecorator;
import withPattern.ResidenceWithSuiteDecorator;

public class DemoWithPattern {

	public static void main(String[] args) {
		
		//init value of 50K and init room count of 5 (living room, kitchen, bathroom
		// and 2 bedrooms 
		
		Residence house = new House( BigDecimal.valueOf(50000), 5);
		
		Residence houseWithPool = new ResidenceWithPoolDecorator(house);
		
		Residence houseWithSuite = new ResidenceWithSuiteDecorator(houseWithPool);
		
		Residence houseWith2Suites = new ResidenceWithSuiteDecorator(houseWithSuite);
		
		//Simple House
		System.out.println("Casa simples");
		System.out.println("Room count: "+ house.getRoomCount());
		System.out.println("Cost: "+house.getCost());
		
		
		//House with a pool
		System.out.println("\n\nCasa com piscina");
		System.out.println("Room count: "+ houseWithPool.getRoomCount());
		System.out.println("Cost: "+houseWithPool.getCost());
		
		
		//House with 1 suite and a pool
		System.out.println("\n\nCasa com 1 su�te e piscina");
		System.out.println("Room count: "+ houseWithSuite.getRoomCount());
		System.out.println("Cost: "+houseWithSuite.getCost());
		
		
		//House with 2 suites and a pool
		System.out.println("\n\nCasa com 2 su�tes e piscina");
		System.out.println("Room count: "+ houseWith2Suites.getRoomCount());
		System.out.println("Cost: "+houseWith2Suites.getCost());
		
		

	}

}
