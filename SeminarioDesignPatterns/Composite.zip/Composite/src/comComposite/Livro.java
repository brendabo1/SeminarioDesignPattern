package comComposite;

public class Livro extends ElementoLivraria{
	
	public Livro(String nome, int codigo, double preco) {
		super(nome, codigo, preco);
	}

	@Override
	public void exibirLivro() {
		System.out.println("Livro: " + nome + "\nCodigo: " + codigo + "\n");		
	}

	@Override
	public double getPreco() {
		return this.preco;
	}
	
}
