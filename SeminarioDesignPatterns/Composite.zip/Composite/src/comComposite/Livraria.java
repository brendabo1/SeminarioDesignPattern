package comComposite;

public class Livraria {

	public static void main(String[] args) {
		Estante estanteFiccao = new Estante("Fic�ao", 548);
		Livro livro1 = new Livro("As Aventuras de PI", 001, 19.90);
		Livro livro2 = new Livro("A Revolu��o dos Bichos", 002, 1.0);
		Livro livro3 = new Livro("A Garota do Trem", 003, 2.0);
		estanteFiccao.addElemento(livro1);
		estanteFiccao.addElemento(livro2);
		estanteFiccao.addElemento(livro3);
		System.out.println("Total valores de todos os elementos da Estante Ficcao" + estanteFiccao.getPreco());
		
		
		Estante estanteInfantil = new Estante("Infantil", 123);		
		Livro livro4 = new Livro("Turma da Monica Jovem", 2018, 20.5);
		Livro livro5 = new Livro("Peter Pan", 954, 1.0);
		estanteInfantil.addElemento(livro4);
		estanteInfantil.addElemento(livro5);
		System.out.println("Total valores de todos os elementos da Estante Infantil" + estanteInfantil.getPreco());
		
		Estante estanteAcademica = new Estante("Academica", 300);
		Livro livro6 = new Livro("Misterios da Medicina", 001, 10.90);
		Livro livro7 = new Livro("Psicologia das Cores", 002, 10.90);
		estanteAcademica.addElemento(livro6);
		estanteAcademica.addElemento(livro7);
		System.out.println("Total valores de todos os elementos da Estante Academica" + estanteAcademica.getPreco());
		
		
		//Criando outra estrutura composta por elementos compostos, as estantes
		Estante secaoBrasil = new Estante("Brasil", 055);
		secaoBrasil.addElemento(estanteFiccao);
		secaoBrasil.addElemento(estanteAcademica);
		secaoBrasil.addElemento(estanteInfantil);
		//Acessa recursivamente a composicao at� obter os dados da folha (livro), exibindo todos os elementos cadastrados
		secaoBrasil.exibirLivro();
		

	}

}
