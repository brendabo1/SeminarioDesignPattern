package comComposite;

import java.util.ArrayList;

public class Estante extends ElementoLivraria{
	private ArrayList<ElementoLivraria> listaElementos = new ArrayList<>();

	
	public Estante(String nome, int cod) {
		super(nome, cod, 0.0);
	}

	

	@Override
	public void exibirLivro() {
		System.out.println("Estante: " + nome + "\nCodigo: " + codigo + "\n");
		for(ElementoLivraria elemento : listaElementos) {
			elemento.exibirLivro();
		}
		
	}
	
	public void addElemento(ElementoLivraria elemento) {
		listaElementos.add(elemento);
	}
	
	public void removerElemento(ElementoLivraria elemento) {
		listaElementos.add(elemento);
	}

	@Override
	public double getPreco() {
		this.preco = 0.0;
		for(ElementoLivraria elemento : listaElementos) {
			this.preco += elemento.getPreco();
		}
		return preco;
	}
}
