package comComposite;

public abstract class ElementoLivraria {
	protected String nome;
	protected int codigo;
	protected double preco;
	
	public ElementoLivraria(String nome, int cod, double preco) {
		this.nome = nome;
		this.codigo = cod;
		this.preco = preco;
	}

	
	public abstract void exibirLivro();
	public abstract double getPreco();

}
