package semComposite;

import java.util.ArrayList;

public class EstanteInfantoJuvenil {
	protected String nome;
	protected int codigo;
	protected ArrayList<Livro> listaInfantil = new ArrayList<>();
	
	public EstanteInfantoJuvenil(String nome, int cod) {
		this.nome = nome;
		this.codigo = cod;
	}
	
	public void addInfantil(Livro elemento) {
		this.listaInfantil.add(elemento);
	}
	
	public void removeInfantil(Livro elemento) {
		this.listaInfantil.remove(elemento);
	}
	
	public void exibirEstante() {
		System.out.println("Estante: " + nome + "\nCodigo: " + codigo + "\n");
		for(Livro livro : listaInfantil) {
			livro.exibirLivro();
		}
	}
}