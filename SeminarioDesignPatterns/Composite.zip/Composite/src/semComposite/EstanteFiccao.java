package semComposite;

import java.util.ArrayList;


public class EstanteFiccao {
	protected String nome;
	protected int codigo;
	protected ArrayList<Livro> listaFiccao = new ArrayList<>();
	
	public EstanteFiccao(String nome, int cod) {
		this.nome = nome;
		this.codigo = cod;
	}
	
	public void addFiccao(Livro elemento) {
		this.listaFiccao.add(elemento);
	}
	
	public void removeFiccao(Livro elemento) {
		this.listaFiccao.remove(elemento);
	}
	
	public void exibirEstante() {
		System.out.println("Estante: " + nome + "\nCodigo: " + codigo + "\n");
		for(Livro livro : listaFiccao) {
			livro.exibirLivro();
		}
	}
}


