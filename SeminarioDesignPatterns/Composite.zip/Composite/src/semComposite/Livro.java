package semComposite;

public class Livro {
	private String nome;
	private int cod;
	
	public Livro(String nome, int cod) {
		this.nome =  nome;
		this.cod = cod;
	}
	
	public void exibirLivro() {
		System.out.println("Livro: " + nome + "\nCodigo: " + cod + "\n");		
	}
}
