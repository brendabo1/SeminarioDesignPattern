package semComposite;

import java.util.ArrayList;

public class EstanteAcademicos {
	protected String nome;
	protected int codigo;
	protected ArrayList<Livro> listaAcademico = new ArrayList<>();
	
	public EstanteAcademicos(String nome, int cod) {
		this.nome = nome;
		this.codigo = cod;
	}
	
	public void add(Livro elemento) {
		this.listaAcademico.add(elemento);
	}
	
	public void remove(Livro elemento) {
		this.listaAcademico.remove(elemento);
	}
	
	public void exibirEstante() {
		System.out.println("Estante: " + nome + "\nCodigo: " + codigo + "\n");
		for(Livro livro : listaAcademico) {
			livro.exibirLivro();
		}
	}
}
