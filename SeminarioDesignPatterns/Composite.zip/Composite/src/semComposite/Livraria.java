package semComposite;


public class Livraria {

	public static void main(String[] args) {
		EstanteFiccao ficcao =  new EstanteFiccao("Estante Fic��o", 001);
		
		Livro novoLivro1 = new Livro("As aventuras de Pi", 561);
		Livro novoLivro2 = new Livro("A Revolu��o dos bichos", 974);
		
		ficcao.addFiccao(novoLivro1);
		ficcao.addFiccao(novoLivro2);
		
		EstanteInfantoJuvenil infantil =  new EstanteInfantoJuvenil("Estante Fic��o", 002);
		Livro novoLivro3 = new Livro("Peter Pan", 687);
		Livro novoLivro4 = new Livro("Galinha Pintadinha", 214);
		Livro novoLivro5 = new Livro("Dona Aranha", 926);
		infantil.addInfantil(novoLivro3);
		infantil.addInfantil(novoLivro4);
		infantil.addInfantil(novoLivro5);
		
		EstanteAcademicos academicos =  new EstanteAcademicos("Estante Academicos", 003);
		Livro novoLivro6 = new Livro("Reaftorando Codigo", 875);
		Livro novoLivro7 = new Livro("Psicologia das Cores", 002);
		academicos.add(novoLivro6);
		academicos.add(novoLivro7);
		
		//If acessar Estante Ficcao
		ficcao.exibirEstante();
		//If acessar Estante Infantil
		infantil.exibirEstante();
		//If acessar Estante Academicos
		academicos.exibirEstante();
		
	}

}
